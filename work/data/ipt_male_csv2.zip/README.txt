All Men's Cricket Ireland Inter-Provincial Twenty20 Trophy match data in CSV format
===================================================================================

The background
--------------

As an experiment, after being asked by a user of the site, I started
converting the YAML data provided on the site into a CSV format. That
initial version was heavily influenced by the format used by the baseball
project Retrosheet. I wasn't sure of the usefulness of my CSV format, but
nothing better was suggested so I persisted with it. Later Ashwin Raman
(https://twitter.com/AshwinRaman_) send me a detailed example of a format
he felt might work and, liking what I saw, I started to produce data in
a slightly modified version of that initial example.

This particular zip folder contains the CSV data for...
  All Men's Cricket Ireland Inter-Provincial Twenty20 Trophy matches
...for which we have data.

How you can help
----------------

Providing feedback on the data would be the most helpful. Tell me what you
like and what you don't. Is there anything that is in the JSON data that
you'd like to be included in the CSV? Could something be included in a better
format? General views and comments help, as well as incredibly detailed
feedback. All information is of use to me at this stage. I can only improve
the data if people tell me what does works and what doesn't. I'd like to make
the data as useful as possible but I need your help to do it. Also, which of
the 2 CSV formats do you prefer, this one or the original? Ideally I'd like
to settle on a single CSV format so what should be kept from each?

Finally, any feedback as to the licence the data should be released under
would be greatly appreciated. Licensing is a strange little world and I'd
like to choose the "right" licence. My basic criteria may be that:

  * the data should be free,
  * corrections are encouraged/required to be reported to the project,
  * derivative works are allowed,
  * you can't just take data and sell it.

Feedback, pointers, comments, etc on licensing are welcome.

The format of the data
----------------------

Full documentation of this CSV format can be found at:
  https://cricsheet.org/format/csv_ashwin/
but the following is a brief summary of the details...

This format consists of 2 files per match, although you can get all of
the ball-by-ball data from just one of the files. The files for a match
are named <id>.csv (for the ball-by-ball data), and <id>_info.csv (for
the match info), where <id> is the Cricinfo id for the match. The
ball-by-ball file contains one row per delivery in the match, while the
match info file contains match information such as dates the match was
played, the outcome, and lists of the players involved in the match.

The match info file format
--------------------------

The info section contains the information on the actual match, such as
when and where it was played, any event it was part of, the type of
match etc. The fields included in the info section will each appear as
one or more rows in the data. Some of the fields are required, whereas
some are optional. If a field has multiple values, such as team, then
each value will appear on a row of it's own.

The ball-by-ball file format
----------------------------

The first row of each ball-by-ball CSV file contains the headers for the
file, with each subsequent row providing details on a single delivery.
The headers in the file are:

  * match_id
  * season
  * start_date
  * venue
  * innings
  * ball
  * batting_team
  * bowling_team
  * striker
  * non_striker
  * bowler
  * runs_off_bat
  * extras
  * wides
  * noballs
  * byes
  * legbyes
  * penalty
  * wicket_type
  * player_dismissed
  * other_wicket_type
  * other_player_dismissed

Most of the fields above should, hopefully, be self-explanatory, but some may
benefit from clarification...

"innings" contains the number of the innings within the match. If a match is
one that would normally have 2 innings, such as a T20 or ODI, then any innings
of more than 2 can be regarded as a super over.

"ball" is a combination of the over and delivery. For example, "0.3" represents
the 3rd ball of the 1st over.

"wides", "noballs", "byes", "legbyes", and "penalty" contain the total of each
particular type of extras, or are blank if not relevant to the delivery.

If a wicket occurred on a delivery then "wicket_type" will contain the method
of dismissal, while "player_dismissed" will indicate who was dismissed. There
is also the, admittedly remote, possibility that a second dismissal can be
recorded on the delivery (such as when a player retires on the same delivery
as another dismissal occurs). In this case "other_wicket_type" will record
the reason, while "other_player_dismissed" will show who was dismissed.

Matches included in this archive
--------------------------------

2026-07-29 - club - IPT - male - 1534735 - North-West Warriors vs Leinster Lightning
2026-07-28 - club - IPT - male - 1534734 - North-West Warriors vs Northern Knights
2026-06-17 - club - IPT - male - 1534739 - Leinster Lightning vs North-West Warriors
2026-06-17 - club - IPT - male - 1534738 - North-West Warriors vs Northern Knights
2026-06-16 - club - IPT - male - 1534737 - Northern Knights vs Leinster Lightning
2026-06-03 - club - IPT - male - 1534732 - Northern Knights vs Leinster Lightning
2026-06-02 - club - IPT - male - 1534731 - Leinster Lightning vs North-West Warriors
2025-07-10 - club - IPT - male - 1478083 - Northern Knights vs Leinster Lightning
2025-07-10 - club - IPT - male - 1478082 - Munster Reds vs North-West Warriors
2025-07-09 - club - IPT - male - 1478081 - North-West Warriors vs Leinster Lightning
2025-07-09 - club - IPT - male - 1478080 - Munster Reds vs Northern Knights
2025-07-08 - club - IPT - male - 1478079 - Northern Knights vs North-West Warriors
2025-07-08 - club - IPT - male - 1478078 - Munster Reds vs Leinster Lightning
2025-07-02 - club - IPT - male - 1478075 - Leinster Lightning vs North-West Warriors
2025-07-02 - club - IPT - male - 1478074 - Munster Reds vs Northern Knights
2025-07-01 - club - IPT - male - 1478073 - Northern Knights vs Leinster Lightning
2025-07-01 - club - IPT - male - 1478072 - North-West Warriors vs Munster Reds
2025-06-26 - club - IPT - male - 1478071 - Leinster Lightning vs Northern Knights
2025-06-26 - club - IPT - male - 1478070 - North-West Warriors vs Munster Reds
2025-06-25 - club - IPT - male - 1478069 - Northern Knights vs Munster Reds
2025-06-25 - club - IPT - male - 1478068 - North-West Warriors vs Leinster Lightning
2025-06-24 - club - IPT - male - 1478067 - Munster Reds vs Leinster Lightning
2025-06-24 - club - IPT - male - 1478066 - North-West Warriors vs Northern Knights
2025-06-19 - club - IPT - male - 1478065 - Munster Reds vs Leinster Lightning
2025-06-19 - club - IPT - male - 1478064 - Northern Knights vs North-West Warriors
2025-06-18 - club - IPT - male - 1478063 - Munster Reds vs Northern Knights
2025-06-18 - club - IPT - male - 1478062 - North-West Warriors vs Leinster Lightning
2025-06-17 - club - IPT - male - 1478061 - Leinster Lightning vs Northern Knights
2025-06-17 - club - IPT - male - 1478060 - North-West Warriors vs Munster Reds
2024-09-10 - club - IPT - male - 1430845 - Northern Knights vs Leinster Lightning
2024-09-04 - club - IPT - male - 1430844 - North-West Warriors vs Munster Reds
2024-08-28 - club - IPT - male - 1430843 - North-West Warriors vs Leinster Lightning
2024-08-21 - club - IPT - male - 1430842 - Munster Reds vs Northern Knights
2024-08-14 - club - IPT - male - 1430841 - North-West Warriors vs Northern Knights
2024-08-07 - club - IPT - male - 1430840 - Leinster Lightning vs Munster Reds
2024-06-04 - club - IPT - male - 1430839 - Leinster Lightning vs Northern Knights
2024-06-04 - club - IPT - male - 1430838 - North-West Warriors vs Munster Reds
2024-05-28 - club - IPT - male - 1430837 - Northern Knights vs Munster Reds
2024-05-16 - club - IPT - male - 1430835 - Munster Reds vs Leinster Lightning
2024-05-08 - club - IPT - male - 1430834 - Northern Knights vs North-West Warriors
2024-05-03 - club - IPT - male - 1430833 - Northern Knights vs Leinster Lightning
2024-05-03 - club - IPT - male - 1430832 - Munster Reds vs North-West Warriors
2024-05-02 - club - IPT - male - 1430831 - North-West Warriors vs Leinster Lightning
2024-05-02 - club - IPT - male - 1430830 - Northern Knights vs Munster Reds
2024-05-01 - club - IPT - male - 1430829 - North-West Warriors vs Northern Knights
2024-05-01 - club - IPT - male - 1430828 - Munster Reds vs Leinster Lightning
2023-08-03 - club - IPT - male - 1375554 - Northern Knights vs Leinster Lightning
2023-08-03 - club - IPT - male - 1375553 - Munster Reds vs North-West Warriors
2023-08-01 - club - IPT - male - 1375550 - North-West Warriors vs Northern Knights
2023-08-01 - club - IPT - male - 1375549 - Munster Reds vs Leinster Lightning
2023-07-14 - club - IPT - male - 1375543 - Munster Reds vs North-West Warriors
2023-06-08 - club - IPT - male - 1375542 - Leinster Lightning vs Munster Reds
2023-06-08 - club - IPT - male - 1375541 - North-West Warriors vs Northern Knights
2023-06-07 - club - IPT - male - 1375540 - Munster Reds vs Northern Knights
2023-06-07 - club - IPT - male - 1375539 - North-West Warriors vs Leinster Lightning
2023-06-06 - club - IPT - male - 1375538 - Northern Knights vs Leinster Lightning
2023-06-06 - club - IPT - male - 1375537 - Munster Reds vs North-West Warriors
2022-07-29 - club - IPT - male - 1305451 - Northern Knights vs Leinster Lightning
2022-07-29 - club - IPT - male - 1305450 - North-West Warriors vs Munster Reds
2022-07-28 - club - IPT - male - 1305449 - Leinster Lightning vs North-West Warriors
2022-07-28 - club - IPT - male - 1305448 - Northern Knights vs Munster Reds
2022-07-27 - club - IPT - male - 1305447 - North-West Warriors vs Northern Knights
2022-07-27 - club - IPT - male - 1305446 - Munster Reds vs Leinster Lightning
2022-06-10 - club - IPT - male - 1305441 - Leinster Lightning vs Munster Reds
2022-06-10 - club - IPT - male - 1305440 - Northern Knights vs North-West Warriors
2022-05-29 - club - IPT - male - 1305439 - Leinster Lightning vs Northern Knights
2022-05-29 - club - IPT - male - 1305438 - Munster Reds vs North-West Warriors
2022-05-28 - club - IPT - male - 1305437 - Northern Knights vs Munster Reds
2022-05-28 - club - IPT - male - 1305436 - North-West Warriors vs Leinster Lightning
2022-05-27 - club - IPT - male - 1305435 - Leinster Lightning vs Munster Reds
2022-05-27 - club - IPT - male - 1305434 - Northern Knights vs North-West Warriors
2021-09-19 - club - IPT - male - 1259552 - Leinster Lightning vs North-West Warriors
2021-09-19 - club - IPT - male - 1259551 - Munster Reds vs Northern Knights
2021-09-18 - club - IPT - male - 1259550 - North-West Warriors vs Munster Reds
2021-06-27 - club - IPT - male - 1259546 - Northern Knights vs Munster Reds
2021-06-27 - club - IPT - male - 1259545 - Leinster Lightning vs North-West Warriors
2021-06-26 - club - IPT - male - 1259544 - Leinster Lightning vs Northern Knights
2021-06-26 - club - IPT - male - 1259543 - Munster Reds vs North-West Warriors
2021-06-25 - club - IPT - male - 1259542 - Leinster Lightning vs Munster Reds
2021-06-25 - club - IPT - male - 1259541 - North-West Warriors vs Northern Knights
2021-06-20 - club - IPT - male - 1259540 - Munster Reds vs Northern Knights
2021-06-20 - club - IPT - male - 1259539 - Leinster Lightning vs North-West Warriors
2021-06-19 - club - IPT - male - 1259538 - North-West Warriors vs Munster Reds
2021-06-19 - club - IPT - male - 1259537 - Northern Knights vs Leinster Lightning
2021-06-18 - club - IPT - male - 1259536 - Northern Knights vs North-West Warriors
2021-06-18 - club - IPT - male - 1259535 - Munster Reds vs Leinster Lightning
2020-09-03 - club - IPT - male - 1227511 - Northern Knights vs Leinster Lightning
2020-09-01 - club - IPT - male - 1227508 - Munster Reds vs Leinster Lightning
2020-09-01 - club - IPT - male - 1227507 - North-West Warriors vs Northern Knights
2020-08-27 - club - IPT - male - 1227505 - Leinster Lightning vs North-West Warriors
2020-08-20 - club - IPT - male - 1227503 - Munster Reds vs Leinster Lightning
2020-08-20 - club - IPT - male - 1227502 - North-West Warriors vs Northern Knights
2019-06-24 - club - IPT - male - 1178143 - Northern Knights vs Leinster Lightning
2019-06-23 - club - IPT - male - 1178140 - Northern Knights vs Munster Reds
2019-06-22 - club - IPT - male - 1178139 - Munster Reds vs Leinster Lightning
2019-06-22 - club - IPT - male - 1178138 - North-West Warriors vs Northern Knights
2018-07-08 - club - IPT - male - 1136918 - Munster Reds vs Leinster Lightning
2018-07-08 - club - IPT - male - 1136917 - Northern Knights vs North-West Warriors
2018-07-07 - club - IPT - male - 1136916 - Leinster Lightning vs North-West Warriors
2018-07-07 - club - IPT - male - 1136915 - Northern Knights vs Munster Reds
2018-07-06 - club - IPT - male - 1136914 - Leinster Lightning vs Northern Knights
2018-07-06 - club - IPT - male - 1136913 - North-West Warriors vs Munster Reds
2017-08-11 - club - IPT - male - 1089622 - Munster Reds vs Leinster Lightning
2017-08-11 - club - IPT - male - 1089621 - North-West Warriors vs Northern Knights
2017-07-21 - club - IPT - male - 1089619 - Leinster Lightning vs North-West Warriors
2017-06-23 - club - IPT - male - 1089618 - North-West Warriors vs Munster Reds
2017-06-23 - club - IPT - male - 1089617 - Leinster Lightning vs Northern Knights
2017-06-16 - club - IPT - male - 1089616 - Northern Knights vs North-West Warriors
2017-06-09 - club - IPT - male - 1089613 - Northern Knights vs Leinster Lightning
2017-05-26 - club - IPT - male - 1089611 - Leinster Lightning vs North-West Warriors
2016-05-27 - club - IPT - male - 1002157 - North-West Warriors vs Northern Knights

Consolidated data
-----------------

You may notice that there is an extra CSV file in this archive, called
"all_matches.csv". This file, as the name suggests, contains all of the
ball-by-ball data for matches from the archive in a single CSV. Hopefully
it will make use of the data easier in some cases.

Further information
-------------------

You can find all of our currently available data at https://cricsheet.org/

You can contact me via the following methods:
  Email   : stephen@cricsheet.org
  Mastodon: @cricsheet@deeden.co.uk
