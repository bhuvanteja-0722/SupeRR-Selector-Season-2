All Men's Mzansi Super League match data in CSV format
======================================================

The background
--------------

As an experiment, after being asked by a user of the site, I started
converting the YAML data provided on the site into a CSV format. That
initial version was heavily influenced by the format used by the baseball
project Retrosheet. I wasn't sure of the usefulness of my CSV format, but
nothing better was suggested so I persisted with it. Later Ashwin Raman
(https://twitter.com/AshwinRaman_) send me a detailed example of a format
he felt might work and, liking what I saw, I started to produce data in
a slightly modified version of that initial example.

This particular zip folder contains the CSV data for...
  All Men's Mzansi Super League matches
...for which we have data.

How you can help
----------------

Providing feedback on the data would be the most helpful. Tell me what you
like and what you don't. Is there anything that is in the JSON data that
you'd like to be included in the CSV? Could something be included in a better
format? General views and comments help, as well as incredibly detailed
feedback. All information is of use to me at this stage. I can only improve
the data if people tell me what does works and what doesn't. I'd like to make
the data as useful as possible but I need your help to do it. Also, which of
the 2 CSV formats do you prefer, this one or the original? Ideally I'd like
to settle on a single CSV format so what should be kept from each?

Finally, any feedback as to the licence the data should be released under
would be greatly appreciated. Licensing is a strange little world and I'd
like to choose the "right" licence. My basic criteria may be that:

  * the data should be free,
  * corrections are encouraged/required to be reported to the project,
  * derivative works are allowed,
  * you can't just take data and sell it.

Feedback, pointers, comments, etc on licensing are welcome.

The format of the data
----------------------

Full documentation of this CSV format can be found at:
  https://cricsheet.org/format/csv_ashwin/
but the following is a brief summary of the details...

This format consists of 2 files per match, although you can get all of
the ball-by-ball data from just one of the files. The files for a match
are named <id>.csv (for the ball-by-ball data), and <id>_info.csv (for
the match info), where <id> is the Cricinfo id for the match. The
ball-by-ball file contains one row per delivery in the match, while the
match info file contains match information such as dates the match was
played, the outcome, and lists of the players involved in the match.

The match info file format
--------------------------

The info section contains the information on the actual match, such as
when and where it was played, any event it was part of, the type of
match etc. The fields included in the info section will each appear as
one or more rows in the data. Some of the fields are required, whereas
some are optional. If a field has multiple values, such as team, then
each value will appear on a row of it's own.

The ball-by-ball file format
----------------------------

The first row of each ball-by-ball CSV file contains the headers for the
file, with each subsequent row providing details on a single delivery.
The headers in the file are:

  * match_id
  * season
  * start_date
  * venue
  * innings
  * ball
  * batting_team
  * bowling_team
  * striker
  * non_striker
  * bowler
  * runs_off_bat
  * extras
  * wides
  * noballs
  * byes
  * legbyes
  * penalty
  * wicket_type
  * player_dismissed
  * other_wicket_type
  * other_player_dismissed

Most of the fields above should, hopefully, be self-explanatory, but some may
benefit from clarification...

"innings" contains the number of the innings within the match. If a match is
one that would normally have 2 innings, such as a T20 or ODI, then any innings
of more than 2 can be regarded as a super over.

"ball" is a combination of the over and delivery. For example, "0.3" represents
the 3rd ball of the 1st over.

"wides", "noballs", "byes", "legbyes", and "penalty" contain the total of each
particular type of extras, or are blank if not relevant to the delivery.

If a wicket occurred on a delivery then "wicket_type" will contain the method
of dismissal, while "player_dismissed" will indicate who was dismissed. There
is also the, admittedly remote, possibility that a second dismissal can be
recorded on the delivery (such as when a player retires on the same delivery
as another dismissal occurs). In this case "other_wicket_type" will record
the reason, while "other_player_dismissed" will show who was dismissed.

Matches included in this archive
--------------------------------

2019-12-16 - club - MSL - male - 1202001 - Tshwane Spartans vs Paarl Rocks
2019-12-13 - club - MSL - male - 1202000 - Tshwane Spartans vs Nelson Mandela Bay Giants
2019-12-08 - club - MSL - male - 1201997 - Paarl Rocks vs Nelson Mandela Bay Giants
2019-12-06 - club - MSL - male - 1201995 - Nelson Mandela Bay Giants vs Cape Town Blitz
2019-12-04 - club - MSL - male - 1201993 - Paarl Rocks vs Durban Heat
2019-12-03 - club - MSL - male - 1201992 - Tshwane Spartans vs Nelson Mandela Bay Giants
2019-12-01 - club - MSL - male - 1201991 - Cape Town Blitz vs Tshwane Spartans
2019-12-01 - club - MSL - male - 1201990 - Jozi Stars vs Paarl Rocks
2019-11-30 - club - MSL - male - 1201989 - Nelson Mandela Bay Giants vs Durban Heat
2019-11-29 - club - MSL - male - 1201988 - Paarl Rocks vs Tshwane Spartans
2019-11-28 - club - MSL - male - 1201987 - Cape Town Blitz vs Durban Heat
2019-11-27 - club - MSL - male - 1201986 - Paarl Rocks vs Nelson Mandela Bay Giants
2019-11-24 - club - MSL - male - 1201985 - Tshwane Spartans vs Jozi Stars
2019-11-24 - club - MSL - male - 1201984 - Paarl Rocks vs Cape Town Blitz
2019-11-23 - club - MSL - male - 1201983 - Durban Heat vs Nelson Mandela Bay Giants
2019-11-22 - club - MSL - male - 1201982 - Jozi Stars vs Paarl Rocks
2019-11-21 - club - MSL - male - 1201981 - Tshwane Spartans vs Durban Heat
2019-11-20 - club - MSL - male - 1201980 - Cape Town Blitz vs Nelson Mandela Bay Giants
2019-11-17 - club - MSL - male - 1201979 - Paarl Rocks vs Tshwane Spartans
2019-11-17 - club - MSL - male - 1201978 - Cape Town Blitz vs Durban Heat
2019-11-16 - club - MSL - male - 1201977 - Jozi Stars vs Nelson Mandela Bay Giants
2019-11-14 - club - MSL - male - 1201975 - Cape Town Blitz vs Jozi Stars
2019-11-13 - club - MSL - male - 1201974 - Tshwane Spartans vs Nelson Mandela Bay Giants
2019-11-10 - club - MSL - male - 1201973 - Nelson Mandela Bay Giants vs Jozi Stars
2019-11-10 - club - MSL - male - 1201972 - Paarl Rocks vs Cape Town Blitz
2019-11-08 - club - MSL - male - 1201970 - Cape Town Blitz vs Jozi Stars
2018-12-16 - club - MSL - male - 1162672 - Cape Town Blitz vs Jozi Stars
2018-12-12 - club - MSL - male - 1162670 - Tshwane Spartans vs Durban Heat
2018-12-12 - club - MSL - male - 1162669 - Nelson Mandela Bay Giants vs Paarl Rocks
2018-12-11 - club - MSL - male - 1162668 - Jozi Stars vs Tshwane Spartans
2018-12-09 - club - MSL - male - 1162667 - Cape Town Blitz vs Durban Heat
2018-12-09 - club - MSL - male - 1162666 - Jozi Stars vs Paarl Rocks
2018-12-08 - club - MSL - male - 1162665 - Tshwane Spartans vs Nelson Mandela Bay Giants
2018-12-07 - club - MSL - male - 1162664 - Paarl Rocks vs Cape Town Blitz
2018-12-07 - club - MSL - male - 1162663 - Durban Heat vs Jozi Stars
2018-12-05 - club - MSL - male - 1162662 - Nelson Mandela Bay Giants vs Durban Heat
2018-12-05 - club - MSL - male - 1162661 - Paarl Rocks vs Tshwane Spartans
2018-12-04 - club - MSL - male - 1162660 - Jozi Stars vs Cape Town Blitz
2018-12-02 - club - MSL - male - 1162659 - Jozi Stars vs Nelson Mandela Bay Giants
2018-12-02 - club - MSL - male - 1162658 - Durban Heat vs Paarl Rocks
2018-12-01 - club - MSL - male - 1162657 - Cape Town Blitz vs Tshwane Spartans
2018-11-30 - club - MSL - male - 1162656 - Jozi Stars vs Durban Heat
2018-11-30 - club - MSL - male - 1162655 - Nelson Mandela Bay Giants vs Paarl Rocks
2018-11-28 - club - MSL - male - 1162654 - Paarl Rocks vs Durban Heat
2018-11-28 - club - MSL - male - 1162653 - Jozi Stars vs Tshwane Spartans
2018-11-25 - club - MSL - male - 1162651 - Cape Town Blitz vs Paarl Rocks
2018-11-25 - club - MSL - male - 1162650 - Nelson Mandela Bay Giants vs Tshwane Spartans
2018-11-24 - club - MSL - male - 1162649 - Cape Town Blitz vs Jozi Stars
2018-11-23 - club - MSL - male - 1162648 - Durban Heat vs Nelson Mandela Bay Giants
2018-11-21 - club - MSL - male - 1162647 - Cape Town Blitz vs Nelson Mandela Bay Giants
2018-11-21 - club - MSL - male - 1162646 - Tshwane Spartans vs Durban Heat
2018-11-20 - club - MSL - male - 1162645 - Jozi Stars vs Paarl Rocks
2018-11-18 - club - MSL - male - 1162644 - Tshwane Spartans vs Paarl Rocks
2018-11-18 - club - MSL - male - 1162643 - Durban Heat vs Cape Town Blitz
2018-11-17 - club - MSL - male - 1162642 - Jozi Stars vs Nelson Mandela Bay Giants
2018-11-16 - club - MSL - male - 1162641 - Cape Town Blitz vs Tshwane Spartans

Consolidated data
-----------------

You may notice that there is an extra CSV file in this archive, called
"all_matches.csv". This file, as the name suggests, contains all of the
ball-by-ball data for matches from the archive in a single CSV. Hopefully
it will make use of the data easier in some cases.

Further information
-------------------

You can find all of our currently available data at https://cricsheet.org/

You can contact me via the following methods:
  Email   : stephen@cricsheet.org
  Mastodon: @cricsheet@deeden.co.uk
