All International League T20 match data in CSV format
=====================================================

The background
--------------

As an experiment, after being asked by a user of the site, I started
converting the YAML data provided on the site into a CSV format. That
initial version was heavily influenced by the format used by the baseball
project Retrosheet. I wasn't sure of the usefulness of my CSV format, but
nothing better was suggested so I persisted with it. Later Ashwin Raman
(https://twitter.com/AshwinRaman_) send me a detailed example of a format
he felt might work and, liking what I saw, I started to produce data in
a slightly modified version of that initial example.

This particular zip folder contains the CSV data for...
  All International League T20 matches
...for which we have data.

How you can help
----------------

Providing feedback on the data would be the most helpful. Tell me what you
like and what you don't. Is there anything that is in the JSON data that
you'd like to be included in the CSV? Could something be included in a better
format? General views and comments help, as well as incredibly detailed
feedback. All information is of use to me at this stage. I can only improve
the data if people tell me what does works and what doesn't. I'd like to make
the data as useful as possible but I need your help to do it. Also, which of
the 2 CSV formats do you prefer, this one or the original? Ideally I'd like
to settle on a single CSV format so what should be kept from each?

Finally, any feedback as to the licence the data should be released under
would be greatly appreciated. Licensing is a strange little world and I'd
like to choose the "right" licence. My basic criteria may be that:

  * the data should be free,
  * corrections are encouraged/required to be reported to the project,
  * derivative works are allowed,
  * you can't just take data and sell it.

Feedback, pointers, comments, etc on licensing are welcome.

The format of the data
----------------------

Full documentation of this CSV format can be found at:
  https://cricsheet.org/format/csv_ashwin/
but the following is a brief summary of the details...

This format consists of 2 files per match, although you can get all of
the ball-by-ball data from just one of the files. The files for a match
are named <id>.csv (for the ball-by-ball data), and <id>_info.csv (for
the match info), where <id> is the Cricinfo id for the match. The
ball-by-ball file contains one row per delivery in the match, while the
match info file contains match information such as dates the match was
played, the outcome, and lists of the players involved in the match.

The match info file format
--------------------------

The info section contains the information on the actual match, such as
when and where it was played, any event it was part of, the type of
match etc. The fields included in the info section will each appear as
one or more rows in the data. Some of the fields are required, whereas
some are optional. If a field has multiple values, such as team, then
each value will appear on a row of it's own.

The ball-by-ball file format
----------------------------

The first row of each ball-by-ball CSV file contains the headers for the
file, with each subsequent row providing details on a single delivery.
The headers in the file are:

  * match_id
  * season
  * start_date
  * venue
  * innings
  * ball
  * batting_team
  * bowling_team
  * striker
  * non_striker
  * bowler
  * runs_off_bat
  * extras
  * wides
  * noballs
  * byes
  * legbyes
  * penalty
  * wicket_type
  * player_dismissed
  * other_wicket_type
  * other_player_dismissed

Most of the fields above should, hopefully, be self-explanatory, but some may
benefit from clarification...

"innings" contains the number of the innings within the match. If a match is
one that would normally have 2 innings, such as a T20 or ODI, then any innings
of more than 2 can be regarded as a super over.

"ball" is a combination of the over and delivery. For example, "0.3" represents
the 3rd ball of the 1st over.

"wides", "noballs", "byes", "legbyes", and "penalty" contain the total of each
particular type of extras, or are blank if not relevant to the delivery.

If a wicket occurred on a delivery then "wicket_type" will contain the method
of dismissal, while "player_dismissed" will indicate who was dismissed. There
is also the, admittedly remote, possibility that a second dismissal can be
recorded on the delivery (such as when a player retires on the same delivery
as another dismissal occurs). In this case "other_wicket_type" will record
the reason, while "other_player_dismissed" will show who was dismissed.

Matches included in this archive
--------------------------------

2026-01-04 - club - ILT - male - 1501351 - Desert Vipers vs MI Emirates
2026-01-02 - club - ILT - male - 1501350 - Abu Dhabi Knight Riders vs MI Emirates
2026-01-01 - club - ILT - male - 1501349 - Abu Dhabi Knight Riders vs Dubai Capitals
2025-12-30 - club - ILT - male - 1501348 - Desert Vipers vs MI Emirates
2025-12-28 - club - ILT - male - 1501347 - Abu Dhabi Knight Riders vs Gulf Giants
2025-12-27 - club - ILT - male - 1501346 - Dubai Capitals vs MI Emirates
2025-12-26 - club - ILT - male - 1501345 - Sharjah Warriorz vs Desert Vipers
2025-12-24 - club - ILT - male - 1501344 - Sharjah Warriorz vs Dubai Capitals
2025-12-23 - club - ILT - male - 1501343 - Gulf Giants vs MI Emirates
2025-12-22 - club - ILT - male - 1501342 - Abu Dhabi Knight Riders vs Sharjah Warriorz
2025-12-21 - club - ILT - male - 1501341 - Desert Vipers vs MI Emirates
2025-12-21 - club - ILT - male - 1501340 - Gulf Giants vs Dubai Capitals
2025-12-20 - club - ILT - male - 1501339 - Sharjah Warriorz vs Desert Vipers
2025-12-20 - club - ILT - male - 1501338 - MI Emirates vs Abu Dhabi Knight Riders
2025-12-19 - club - ILT - male - 1501337 - Dubai Capitals vs Sharjah Warriorz
2025-12-18 - club - ILT - male - 1501336 - Gulf Giants vs Abu Dhabi Knight Riders
2025-12-17 - club - ILT - male - 1501335 - MI Emirates vs Dubai Capitals
2025-12-16 - club - ILT - male - 1501334 - Abu Dhabi Knight Riders vs Desert Vipers
2025-12-15 - club - ILT - male - 1501333 - Sharjah Warriorz vs Gulf Giants
2025-12-14 - club - ILT - male - 1501332 - Dubai Capitals vs Desert Vipers
2025-12-14 - club - ILT - male - 1501331 - Sharjah Warriorz vs MI Emirates
2025-12-13 - club - ILT - male - 1501330 - Dubai Capitals vs Abu Dhabi Knight Riders
2025-12-12 - club - ILT - male - 1501329 - Gulf Giants vs Desert Vipers
2025-12-11 - club - ILT - male - 1501328 - Abu Dhabi Knight Riders vs MI Emirates
2025-12-10 - club - ILT - male - 1501327 - Sharjah Warriorz vs Gulf Giants
2025-12-09 - club - ILT - male - 1501326 - Desert Vipers vs MI Emirates
2025-12-08 - club - ILT - male - 1501325 - Gulf Giants vs Desert Vipers
2025-12-07 - club - ILT - male - 1501324 - Dubai Capitals vs Abu Dhabi Knight Riders
2025-12-07 - club - ILT - male - 1501323 - MI Emirates vs Sharjah Warriorz
2025-12-06 - club - ILT - male - 1501322 - Dubai Capitals vs Gulf Giants
2025-12-05 - club - ILT - male - 1501321 - Abu Dhabi Knight Riders vs Desert Vipers
2025-12-04 - club - ILT - male - 1501320 - MI Emirates vs Gulf Giants
2025-12-03 - club - ILT - male - 1501319 - Abu Dhabi Knight Riders vs Sharjah Warriorz
2025-12-02 - club - ILT - male - 1501318 - Dubai Capitals vs Desert Vipers
2025-02-09 - club - ILT - male - 1462206 - Desert Vipers vs Dubai Capitals
2025-02-07 - club - ILT - male - 1462205 - Sharjah Warriorz vs Desert Vipers
2025-02-06 - club - ILT - male - 1462204 - MI Emirates vs Sharjah Warriorz
2025-02-05 - club - ILT - male - 1462203 - Desert Vipers vs Dubai Capitals
2025-02-03 - club - ILT - male - 1462202 - Desert Vipers vs Dubai Capitals
2025-02-02 - club - ILT - male - 1462201 - Dubai Capitals vs Abu Dhabi Knight Riders
2025-02-02 - club - ILT - male - 1462200 - MI Emirates vs Sharjah Warriorz
2025-02-01 - club - ILT - male - 1462199 - Abu Dhabi Knight Riders vs Gulf Giants
2025-01-31 - club - ILT - male - 1462198 - Gulf Giants vs MI Emirates
2025-01-30 - club - ILT - male - 1462197 - Abu Dhabi Knight Riders vs Sharjah Warriorz
2025-01-29 - club - ILT - male - 1462196 - Gulf Giants vs Desert Vipers
2025-01-28 - club - ILT - male - 1462195 - Dubai Capitals vs Sharjah Warriorz
2025-01-27 - club - ILT - male - 1462194 - MI Emirates vs Desert Vipers
2025-01-26 - club - ILT - male - 1462193 - Sharjah Warriorz vs Gulf Giants
2025-01-26 - club - ILT - male - 1462192 - Abu Dhabi Knight Riders vs Dubai Capitals
2025-01-25 - club - ILT - male - 1462191 - MI Emirates vs Gulf Giants
2025-01-25 - club - ILT - male - 1462190 - Sharjah Warriorz vs Desert Vipers
2025-01-24 - club - ILT - male - 1462189 - Abu Dhabi Knight Riders vs MI Emirates
2025-01-23 - club - ILT - male - 1462188 - Gulf Giants vs Dubai Capitals
2025-01-22 - club - ILT - male - 1462187 - Sharjah Warriorz vs Desert Vipers
2025-01-21 - club - ILT - male - 1462186 - MI Emirates vs Abu Dhabi Knight Riders
2025-01-20 - club - ILT - male - 1462185 - Desert Vipers vs Dubai Capitals
2025-01-19 - club - ILT - male - 1462184 - Abu Dhabi Knight Riders vs Gulf Giants
2025-01-19 - club - ILT - male - 1462183 - Sharjah Warriorz vs MI Emirates
2025-01-18 - club - ILT - male - 1462182 - Dubai Capitals vs Gulf Giants
2025-01-18 - club - ILT - male - 1462181 - Desert Vipers vs Abu Dhabi Knight Riders
2025-01-17 - club - ILT - male - 1462180 - Dubai Capitals vs Sharjah Warriorz
2025-01-16 - club - ILT - male - 1462179 - MI Emirates vs Desert Vipers
2025-01-15 - club - ILT - male - 1462178 - Abu Dhabi Knight Riders vs Sharjah Warriorz
2025-01-14 - club - ILT - male - 1462177 - Gulf Giants vs Desert Vipers
2025-01-13 - club - ILT - male - 1462176 - MI Emirates vs Dubai Capitals
2025-01-12 - club - ILT - male - 1462175 - Gulf Giants vs Sharjah Warriorz
2025-01-12 - club - ILT - male - 1462174 - Abu Dhabi Knight Riders vs Desert Vipers
2025-01-11 - club - ILT - male - 1462173 - Dubai Capitals vs MI Emirates
2024-02-17 - club - ILT - male - 1406922 - MI Emirates vs Dubai Capitals
2024-02-15 - club - ILT - male - 1406921 - Gulf Giants vs Dubai Capitals
2024-02-14 - club - ILT - male - 1406919 - MI Emirates vs Gulf Giants
2024-02-13 - club - ILT - male - 1406920 - Dubai Capitals vs Abu Dhabi Knight Riders
2024-02-11 - club - ILT - male - 1406918 - Sharjah Warriors vs Desert Vipers
2024-02-10 - club - ILT - male - 1406917 - Dubai Capitals vs MI Emirates
2024-02-10 - club - ILT - male - 1406916 - Gulf Giants vs Abu Dhabi Knight Riders
2024-02-09 - club - ILT - male - 1406915 - Desert Vipers vs Dubai Capitals
2024-02-08 - club - ILT - male - 1406914 - Gulf Giants vs MI Emirates
2024-02-07 - club - ILT - male - 1406913 - Abu Dhabi Knight Riders vs Sharjah Warriors
2024-02-06 - club - ILT - male - 1406912 - Gulf Giants vs Dubai Capitals
2024-02-05 - club - ILT - male - 1406911 - Sharjah Warriors vs Abu Dhabi Knight Riders
2024-02-04 - club - ILT - male - 1406910 - Gulf Giants vs Sharjah Warriors
2024-02-04 - club - ILT - male - 1406909 - MI Emirates vs Desert Vipers
2024-02-03 - club - ILT - male - 1406908 - Abu Dhabi Knight Riders vs Dubai Capitals
2024-02-03 - club - ILT - male - 1406907 - Gulf Giants vs Desert Vipers
2024-02-02 - club - ILT - male - 1406906 - Sharjah Warriors vs MI Emirates
2024-02-01 - club - ILT - male - 1406905 - Desert Vipers vs Dubai Capitals
2024-01-31 - club - ILT - male - 1406904 - Gulf Giants vs Abu Dhabi Knight Riders
2024-01-30 - club - ILT - male - 1406903 - MI Emirates vs Desert Vipers
2024-01-29 - club - ILT - male - 1406902 - Dubai Capitals vs Sharjah Warriors
2024-01-28 - club - ILT - male - 1406901 - Sharjah Warriors vs Desert Vipers
2024-01-28 - club - ILT - male - 1406900 - Abu Dhabi Knight Riders vs MI Emirates
2024-01-27 - club - ILT - male - 1406899 - Dubai Capitals vs Gulf Giants
2024-01-27 - club - ILT - male - 1406898 - Desert Vipers vs Abu Dhabi Knight Riders
2024-01-26 - club - ILT - male - 1406897 - MI Emirates vs Sharjah Warriors
2024-01-25 - club - ILT - male - 1406896 - Abu Dhabi Knight Riders vs Dubai Capitals
2024-01-24 - club - ILT - male - 1406895 - Gulf Giants vs Desert Vipers
2024-01-23 - club - ILT - male - 1406894 - Abu Dhabi Knight Riders vs MI Emirates
2024-01-22 - club - ILT - male - 1406893 - Dubai Capitals vs Sharjah Warriors
2024-01-21 - club - ILT - male - 1406892 - MI Emirates vs Gulf Giants
2024-01-21 - club - ILT - male - 1406891 - Desert Vipers vs Abu Dhabi Knight Riders
2024-01-20 - club - ILT - male - 1406890 - MI Emirates vs Dubai Capitals
2024-01-19 - club - ILT - male - 1406889 - Gulf Giants vs Sharjah Warriors
2023-02-12 - club - ILT - male - 1346949 - Desert Vipers vs Gulf Giants
2023-02-10 - club - ILT - male - 1346948 - MI Emirates vs Gulf Giants
2023-02-09 - club - ILT - male - 1346947 - Dubai Capitals vs MI Emirates
2023-02-08 - club - ILT - male - 1346946 - Desert Vipers vs Gulf Giants
2023-02-06 - club - ILT - male - 1346945 - Sharjah Warriors vs Gulf Giants
2023-02-05 - club - ILT - male - 1346944 - MI Emirates vs Dubai Capitals
2023-02-04 - club - ILT - male - 1346943 - Sharjah Warriors vs Abu Dhabi Knight Riders
2023-02-04 - club - ILT - male - 1346942 - Gulf Giants vs Desert Vipers
2023-02-03 - club - ILT - male - 1346941 - MI Emirates vs Abu Dhabi Knight Riders
2023-02-02 - club - ILT - male - 1346940 - Desert Vipers vs Dubai Capitals
2023-02-01 - club - ILT - male - 1346939 - MI Emirates vs Gulf Giants
2023-01-31 - club - ILT - male - 1346938 - Desert Vipers vs Sharjah Warriors
2023-01-30 - club - ILT - male - 1346937 - Abu Dhabi Knight Riders vs Dubai Capitals
2023-01-29 - club - ILT - male - 1346936 - MI Emirates vs Desert Vipers
2023-01-28 - club - ILT - male - 1346935 - Desert Vipers vs Dubai Capitals
2023-01-28 - club - ILT - male - 1346934 - Abu Dhabi Knight Riders vs Sharjah Warriors
2023-01-26 - club - ILT - male - 1346932 - Dubai Capitals vs Sharjah Warriors
2023-01-24 - club - ILT - male - 1346930 - MI Emirates vs Desert Vipers
2023-01-23 - club - ILT - male - 1346929 - Sharjah Warriors vs Gulf Giants
2023-01-22 - club - ILT - male - 1346928 - Dubai Capitals vs MI Emirates
2023-01-22 - club - ILT - male - 1346927 - Desert Vipers vs Gulf Giants
2023-01-21 - club - ILT - male - 1346926 - Abu Dhabi Knight Riders vs MI Emirates
2023-01-21 - club - ILT - male - 1346925 - Dubai Capitals vs Sharjah Warriors
2023-01-20 - club - ILT - male - 1346924 - Desert Vipers vs Abu Dhabi Knight Riders
2023-01-19 - club - ILT - male - 1346923 - Gulf Giants vs Dubai Capitals
2023-01-18 - club - ILT - male - 1346922 - Abu Dhabi Knight Riders vs Desert Vipers
2023-01-17 - club - ILT - male - 1346921 - Sharjah Warriors vs MI Emirates
2023-01-16 - club - ILT - male - 1346920 - Dubai Capitals vs Gulf Giants
2023-01-15 - club - ILT - male - 1346919 - Sharjah Warriors vs Desert Vipers
2023-01-15 - club - ILT - male - 1346918 - Abu Dhabi Knight Riders vs Gulf Giants
2023-01-14 - club - ILT - male - 1346917 - MI Emirates vs Sharjah Warriors
2023-01-13 - club - ILT - male - 1346916 - Dubai Capitals vs Abu Dhabi Knight Riders

Consolidated data
-----------------

You may notice that there is an extra CSV file in this archive, called
"all_matches.csv". This file, as the name suggests, contains all of the
ball-by-ball data for matches from the archive in a single CSV. Hopefully
it will make use of the data easier in some cases.

Further information
-------------------

You can find all of our currently available data at https://cricsheet.org/

You can contact me via the following methods:
  Email   : stephen@cricsheet.org
  Mastodon: @cricsheet@deeden.co.uk
