All Men's Major Clubs T20 Tournament match data in CSV format
=============================================================

The background
--------------

As an experiment, after being asked by a user of the site, I started
converting the YAML data provided on the site into a CSV format. That
initial version was heavily influenced by the format used by the baseball
project Retrosheet. I wasn't sure of the usefulness of my CSV format, but
nothing better was suggested so I persisted with it. Later Ashwin Raman
(https://twitter.com/AshwinRaman_) send me a detailed example of a format
he felt might work and, liking what I saw, I started to produce data in
a slightly modified version of that initial example.

This particular zip folder contains the CSV data for...
  All Men's Major Clubs T20 Tournament matches
...for which we have data.

How you can help
----------------

Providing feedback on the data would be the most helpful. Tell me what you
like and what you don't. Is there anything that is in the JSON data that
you'd like to be included in the CSV? Could something be included in a better
format? General views and comments help, as well as incredibly detailed
feedback. All information is of use to me at this stage. I can only improve
the data if people tell me what does works and what doesn't. I'd like to make
the data as useful as possible but I need your help to do it. Also, which of
the 2 CSV formats do you prefer, this one or the original? Ideally I'd like
to settle on a single CSV format so what should be kept from each?

Finally, any feedback as to the licence the data should be released under
would be greatly appreciated. Licensing is a strange little world and I'd
like to choose the "right" licence. My basic criteria may be that:

  * the data should be free,
  * corrections are encouraged/required to be reported to the project,
  * derivative works are allowed,
  * you can't just take data and sell it.

Feedback, pointers, comments, etc on licensing are welcome.

The format of the data
----------------------

Full documentation of this CSV format can be found at:
  https://cricsheet.org/format/csv_ashwin/
but the following is a brief summary of the details...

This format consists of 2 files per match, although you can get all of
the ball-by-ball data from just one of the files. The files for a match
are named <id>.csv (for the ball-by-ball data), and <id>_info.csv (for
the match info), where <id> is the Cricinfo id for the match. The
ball-by-ball file contains one row per delivery in the match, while the
match info file contains match information such as dates the match was
played, the outcome, and lists of the players involved in the match.

The match info file format
--------------------------

The info section contains the information on the actual match, such as
when and where it was played, any event it was part of, the type of
match etc. The fields included in the info section will each appear as
one or more rows in the data. Some of the fields are required, whereas
some are optional. If a field has multiple values, such as team, then
each value will appear on a row of it's own.

The ball-by-ball file format
----------------------------

The first row of each ball-by-ball CSV file contains the headers for the
file, with each subsequent row providing details on a single delivery.
The headers in the file are:

  * match_id
  * season
  * start_date
  * venue
  * innings
  * ball
  * batting_team
  * bowling_team
  * striker
  * non_striker
  * bowler
  * runs_off_bat
  * extras
  * wides
  * noballs
  * byes
  * legbyes
  * penalty
  * wicket_type
  * player_dismissed
  * other_wicket_type
  * other_player_dismissed

Most of the fields above should, hopefully, be self-explanatory, but some may
benefit from clarification...

"innings" contains the number of the innings within the match. If a match is
one that would normally have 2 innings, such as a T20 or ODI, then any innings
of more than 2 can be regarded as a super over.

"ball" is a combination of the over and delivery. For example, "0.3" represents
the 3rd ball of the 1st over.

"wides", "noballs", "byes", "legbyes", and "penalty" contain the total of each
particular type of extras, or are blank if not relevant to the delivery.

If a wicket occurred on a delivery then "wicket_type" will contain the method
of dismissal, while "player_dismissed" will indicate who was dismissed. There
is also the, admittedly remote, possibility that a second dismissal can be
recorded on the delivery (such as when a player retires on the same delivery
as another dismissal occurs). In this case "other_wicket_type" will record
the reason, while "other_player_dismissed" will show who was dismissed.

Matches included in this archive
--------------------------------

2026-09-16 - club - MCT - male - 1535542 - Sinhalese Sports Club vs Tamil Union Cricket and Athletic Club
2026-09-13 - club - MCT - male - 1535541 - Sinhalese Sports Club vs Nondescripts Cricket Club
2026-09-13 - club - MCT - male - 1535540 - Tamil Union Cricket and Athletic Club vs Colombo Cricket Club
2026-09-09 - club - MCT - male - 1535539 - Colombo Cricket Club vs Ace Capital Cricket Club
2026-09-09 - club - MCT - male - 1535538 - Moors Sports Club vs Nondescripts Cricket Club
2026-09-09 - club - MCT - male - 1535537 - Sinhalese Sports Club vs Police Sports Club
2026-09-09 - club - MCT - male - 1535536 - Tamil Union Cricket and Athletic Club vs Panadura Sports Club
2026-09-05 - club - MCT - male - 1535511 - Nondescripts Cricket Club vs Colts Cricket Club
2026-09-05 - club - MCT - male - 1535510 - Moors Sports Club vs Burgher Recreation Club
2026-09-05 - club - MCT - male - 1535509 - Ace Capital Cricket Club vs Sinhalese Sports Club
2026-09-05 - club - MCT - male - 1535508 - Nugegoda Sports Welfare Club vs Police Sports Club
2026-09-05 - club - MCT - male - 1535507 - Panadura Sports Club vs Badureliya Sports Club
2026-09-05 - club - MCT - male - 1535506 - Kurunegala Youth Cricket Club vs Colombo Cricket Club
2026-09-01 - club - MCT - male - 1535505 - Colts Cricket Club vs Bloomfield Cricket and Athletic Club
2026-09-01 - club - MCT - male - 1535504 - Burgher Recreation Club vs Tamil Union Cricket and Athletic Club
2026-09-01 - club - MCT - male - 1535503 - Ace Capital Cricket Club vs Nondescripts Cricket Club
2026-09-01 - club - MCT - male - 1535502 - Nugegoda Sports Welfare Club vs Moors Sports Club
2026-09-01 - club - MCT - male - 1535501 - Colombo Cricket Club vs Police Sports Club
2026-09-01 - club - MCT - male - 1535500 - Panadura Sports Club vs Sinhalese Sports Club
2026-08-28 - club - MCT - male - 1535499 - Bloomfield Cricket and Athletic Club vs Ace Capital Cricket Club
2026-08-28 - club - MCT - male - 1535498 - Tamil Union Cricket and Athletic Club vs Nugegoda Sports Welfare Club
2026-08-28 - club - MCT - male - 1535497 - Colts Cricket Club vs Badureliya Sports Club
2026-08-28 - club - MCT - male - 1535496 - Kurunegala Youth Cricket Club vs Burgher Recreation Club
2026-08-28 - club - MCT - male - 1535495 - Nondescripts Cricket Club vs Sinhalese Sports Club
2026-08-28 - club - MCT - male - 1535494 - Police Sports Club vs Moors Sports Club
2026-08-24 - club - MCT - male - 1535535 - Ace Capital Cricket Club vs Badureliya Sports Club
2026-08-24 - club - MCT - male - 1535534 - Nugegoda Sports Welfare Club vs Kurunegala Youth Cricket Club
2026-08-24 - club - MCT - male - 1535533 - Bloomfield Cricket and Athletic Club vs Sinhalese Sports Club
2026-08-24 - club - MCT - male - 1535532 - Police Sports Club vs Tamil Union Cricket and Athletic Club
2026-08-24 - club - MCT - male - 1535531 - Colombo Cricket Club vs Moors Sports Club
2026-08-24 - club - MCT - male - 1535530 - Panadura Sports Club vs Nondescripts Cricket Club
2026-08-20 - club - MCT - male - 1535529 - Sinhalese Sports Club vs Badureliya Sports Club
2026-08-20 - club - MCT - male - 1535528 - Police Sports Club vs Kurunegala Youth Cricket Club
2026-08-20 - club - MCT - male - 1535527 - Moors Sports Club vs Tamil Union Cricket and Athletic Club
2026-08-20 - club - MCT - male - 1535526 - Nondescripts Cricket Club vs Bloomfield Cricket and Athletic Club
2026-08-20 - club - MCT - male - 1535525 - Panadura Sports Club vs Colts Cricket Club
2026-08-20 - club - MCT - male - 1535524 - Burgher Recreation Club vs Colombo Cricket Club
2026-08-17 - club - MCT - male - 1535520 - Nugegoda Sports Welfare Club vs Burgher Recreation Club
2026-08-16 - club - MCT - male - 1535523 - Kurunegala Youth Cricket Club vs Moors Sports Club
2026-08-16 - club - MCT - male - 1535522 - Nondescripts Cricket Club vs Badureliya Sports Club
2026-08-16 - club - MCT - male - 1535521 - Colts Cricket Club vs Ace Capital Cricket Club
2026-08-16 - club - MCT - male - 1535519 - Bloomfield Cricket and Athletic Club vs Panadura Sports Club
2026-08-16 - club - MCT - male - 1535518 - Colombo Cricket Club vs Tamil Union Cricket and Athletic Club
2026-08-12 - club - MCT - male - 1535517 - Sinhalese Sports Club vs Colts Cricket Club
2026-08-12 - club - MCT - male - 1535516 - Bloomfield Cricket and Athletic Club vs Badureliya Sports Club
2026-08-12 - club - MCT - male - 1535515 - Burgher Recreation Club vs Police Sports Club
2026-08-12 - club - MCT - male - 1535514 - Kurunegala Youth Cricket Club vs Tamil Union Cricket and Athletic Club
2026-08-12 - club - MCT - male - 1535513 - Panadura Sports Club vs Ace Capital Cricket Club
2026-08-12 - club - MCT - male - 1535512 - Nugegoda Sports Welfare Club vs Colombo Cricket Club
2025-06-15 - club - MCT - male - 1485338 - Panadura Sports Club vs Colombo Cricket Club
2025-06-13 - club - MCT - male - 1485337 - Moors Sports Club vs Colombo Cricket Club
2025-06-13 - club - MCT - male - 1485336 - Panadura Sports Club vs Nondescripts Cricket Club
2025-06-12 - club - MCT - male - 1485335 - Panadura Sports Club vs Colts Cricket Club
2025-06-12 - club - MCT - male - 1485334 - Moors Sports Club vs Bloomfield Cricket and Athletic Club
2025-06-11 - club - MCT - male - 1485333 - Colombo Cricket Club vs Burgher Recreation Club
2025-06-11 - club - MCT - male - 1485332 - Tamil Union Cricket and Athletic Club vs Nondescripts Cricket Club
2025-06-08 - club - MCT - male - 1485331 - Colts Cricket Club vs Police Sports Club
2025-06-08 - club - MCT - male - 1485330 - Badureliya Sports Club vs Moors Sports Club
2025-06-08 - club - MCT - male - 1485329 - Chilaw Marians Cricket Club vs Burgher Recreation Club
2025-06-08 - club - MCT - male - 1485328 - Bloomfield Cricket and Athletic Club vs Tamil Union Cricket and Athletic Club
2025-06-08 - club - MCT - male - 1485327 - Nondescripts Cricket Club vs Ace Capital Cricket Club
2025-06-08 - club - MCT - male - 1485326 - Panadura Sports Club vs Colombo Cricket Club
2025-06-06 - club - MCT - male - 1485325 - Nondescripts Cricket Club vs Panadura Sports Club
2025-06-06 - club - MCT - male - 1485324 - Nugegoda Sports Welfare Club vs Colts Cricket Club
2025-06-06 - club - MCT - male - 1485323 - Colombo Cricket Club vs Kurunegala Youth Cricket Club
2025-06-06 - club - MCT - male - 1485322 - Tamil Union Cricket and Athletic Club vs Chilaw Marians Cricket Club
2025-06-06 - club - MCT - male - 1485321 - Badureliya Sports Club vs Ace Capital Cricket Club
2025-06-06 - club - MCT - male - 1485320 - Police Sports Club vs Bloomfield Cricket and Athletic Club
2025-06-05 - club - MCT - male - 1485319 - Chilaw Marians Cricket Club vs Police Sports Club
2025-06-05 - club - MCT - male - 1485318 - Moors Sports Club vs Nondescripts Cricket Club
2025-06-05 - club - MCT - male - 1485317 - Tamil Union Cricket and Athletic Club vs Nugegoda Sports Welfare Club
2025-06-05 - club - MCT - male - 1485316 - Panadura Sports Club vs Badureliya Sports Club
2025-06-05 - club - MCT - male - 1485315 - Bloomfield Cricket and Athletic Club vs Burgher Recreation Club
2025-06-05 - club - MCT - male - 1485314 - Kurunegala Youth Cricket Club vs Ace Capital Cricket Club
2025-05-28 - club - MCT - male - 1485309 - Nugegoda Sports Welfare Club vs Chilaw Marians Cricket Club
2025-05-26 - club - MCT - male - 1485307 - Tamil Union Cricket and Athletic Club vs Police Sports Club
2025-05-26 - club - MCT - male - 1485306 - Ace Capital Cricket Club vs Panadura Sports Club
2025-05-25 - club - MCT - male - 1485301 - Kurunegala Youth Cricket Club vs Panadura Sports Club
2025-05-25 - club - MCT - male - 1485300 - Chilaw Marians Cricket Club vs Bloomfield Cricket and Athletic Club
2025-05-25 - club - MCT - male - 1485299 - Badureliya Sports Club vs Nondescripts Cricket Club
2025-05-25 - club - MCT - male - 1485298 - Nugegoda Sports Welfare Club vs Police Sports Club
2025-05-25 - club - MCT - male - 1485297 - Burgher Recreation Club vs Colts Cricket Club
2025-05-25 - club - MCT - male - 1485296 - Moors Sports Club vs Colombo Cricket Club
2025-05-16 - club - MCT - male - 1485295 - Tamil Union Cricket and Athletic Club vs Colts Cricket Club
2025-05-16 - club - MCT - male - 1485294 - Kurunegala Youth Cricket Club vs Nondescripts Cricket Club
2025-05-16 - club - MCT - male - 1485293 - Panadura Sports Club vs Moors Sports Club
2025-05-16 - club - MCT - male - 1485292 - Ace Capital Cricket Club vs Colombo Cricket Club
2025-05-16 - club - MCT - male - 1485291 - Nugegoda Sports Welfare Club vs Bloomfield Cricket and Athletic Club
2025-05-16 - club - MCT - male - 1485290 - Burgher Recreation Club vs Police Sports Club
2024-06-28 - club - MCT - male - 1432991 - Bloomfield Cricket and Athletic Club vs Nondescripts Cricket Club
2024-06-26 - club - MCT - male - 1432990 - Moors Sports Club vs Bloomfield Cricket and Athletic Club
2024-06-26 - club - MCT - male - 1432989 - Burgher Recreation Club vs Nondescripts Cricket Club
2024-06-24 - club - MCT - male - 1432988 - Burgher Recreation Club vs Tamil Union Cricket and Athletic Club
2024-06-24 - club - MCT - male - 1432987 - Ace Capital Cricket Club vs Moors Sports Club
2024-06-24 - club - MCT - male - 1432985 - Colts Cricket Club vs Nondescripts Cricket Club
2024-05-18 - club - MCT - male - 1432980 - Kurunegala Youth Cricket Club vs Bloomfield Cricket and Athletic Club
2024-05-18 - club - MCT - male - 1432979 - Panadura Sports Club vs Colts Cricket Club
2024-05-18 - club - MCT - male - 1432977 - Police Sports Club vs Nondescripts Cricket Club
2024-05-17 - club - MCT - male - 1432976 - Ace Capital Cricket Club vs Tamil Union Cricket and Athletic Club
2024-05-17 - club - MCT - male - 1432975 - Burgher Recreation Club vs Moors Sports Club
2024-05-17 - club - MCT - male - 1432974 - Sinhalese Sports Club vs Negombo Cricket Club
2024-05-17 - club - MCT - male - 1432973 - Badureliya Sports Club vs Chilaw Marians Cricket Club
2024-05-16 - club - MCT - male - 1432972 - Kurunegala Youth Cricket Club vs Colts Cricket Club
2024-05-16 - club - MCT - male - 1432971 - Kandy Customs Cricket Club vs Panadura Sports Club
2024-05-16 - club - MCT - male - 1432970 - Nugegoda Sports Welfare Club vs Police Sports Club
2024-05-16 - club - MCT - male - 1432969 - Nondescripts Cricket Club vs Ragama Cricket Club
2024-05-15 - club - MCT - male - 1432968 - Ace Capital Cricket Club vs Sinhalese Sports Club
2024-05-15 - club - MCT - male - 1432967 - Tamil Union Cricket and Athletic Club vs Negombo Cricket Club
2024-05-15 - club - MCT - male - 1432966 - Chilaw Marians Cricket Club vs Moors Sports Club
2024-05-15 - club - MCT - male - 1432965 - Badureliya Sports Club vs Burgher Recreation Club
2024-05-14 - club - MCT - male - 1432964 - Panadura Sports Club vs Bloomfield Cricket and Athletic Club
2024-05-14 - club - MCT - male - 1432963 - Colombo Cricket Club vs Police Sports Club
2024-05-14 - club - MCT - male - 1432962 - Kandy Customs Cricket Club vs Colts Cricket Club
2024-05-14 - club - MCT - male - 1432961 - Nugegoda Sports Welfare Club vs Nondescripts Cricket Club
2024-05-13 - club - MCT - male - 1432960 - Tamil Union Cricket and Athletic Club vs Sinhalese Sports Club
2024-05-13 - club - MCT - male - 1432959 - Negombo Cricket Club vs Ace Capital Cricket Club
2024-05-13 - club - MCT - male - 1432958 - Chilaw Marians Cricket Club vs Burgher Recreation Club
2024-05-13 - club - MCT - male - 1432957 - Badureliya Sports Club vs Moors Sports Club
2024-05-12 - club - MCT - male - 1432956 - Panadura Sports Club vs Kurunegala Youth Cricket Club
2024-05-12 - club - MCT - male - 1432955 - Kandy Customs Cricket Club vs Bloomfield Cricket and Athletic Club
2024-05-12 - club - MCT - male - 1432953 - Colombo Cricket Club vs Nugegoda Sports Welfare Club

Consolidated data
-----------------

You may notice that there is an extra CSV file in this archive, called
"all_matches.csv". This file, as the name suggests, contains all of the
ball-by-ball data for matches from the archive in a single CSV. Hopefully
it will make use of the data easier in some cases.

Further information
-------------------

You can find all of our currently available data at https://cricsheet.org/

You can contact me via the following methods:
  Email   : stephen@cricsheet.org
  Mastodon: @cricsheet@deeden.co.uk
